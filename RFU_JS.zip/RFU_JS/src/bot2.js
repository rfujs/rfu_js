const LineConnect = require('./connect');
let LINE = require('./main.js');
console.info("\n\
=========================================\n\
BotName: LINE Rfu JS\n\
Version: 0.2.2\n\
Terima Kasih Kepada @Alfathdirk @by_RFU_BOT\n\
=========================================\n\
\nNOTE : Ini Adalah AlphatJS Lama Buatan @Alfathdirk @TCR_TEAM Dan Ini Telah Dikembangin Oleh @RFU_TEAM\nTolong Untuk Tidak Perjual-Belikan Script Ini!\n\
****Nekopoi.host Running****");

/*
| This constant is for auth/login
| 
| Change it to your authToken / your email & password
*/
const auth = {
	authToken: 'EmMUrfd25lrl6dQAi6pf.Him52O9nEswVtT75cFWhxW.YCYRdgldP9ESwbDUUwob83wNBE+AaSO/4PqqmN27r3I=',
	certificate: '18a152daf381d22e90adb8dab9d0603d125803bcb1c3a838fdc5ce62dff477cf',
	email: '',
	password: ''
}

//let client =  new LineConnect();
let client =  new LineConnect(auth);

client.startx().then(async (res) => {
	while(true) {
		try {
			ops = await client.fetchOps(res.operation.revision);
		} catch(error) {
			console.log('error',error)
		}
		for (let op in ops) {
			if(ops[op].revision.toString() != -1){
				res.operation.revision = ops[op].revision;
				LINE.poll(ops[op])
			}
		}
		 //LINE.aLike() " (without quotes) 
	}
});
